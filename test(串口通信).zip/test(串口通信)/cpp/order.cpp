#include "order.h"
#include "uart.hpp"
unsigned char Recv_Buf[buff_size];
qdata buff[30];
Deal_Data *Deal_data=new Deal_Data;
void get_environment(void) //获得环境图
{
	int fd;
	fd = Uart_OpenDev(TTY_DEV); //串口初始化
	usart_config(fd);			//配置完成
	while (1)
	{
		my_Uart_RecvFrame(fd);
		if (get_data(buff, 30))
		{
			printf("%s\n", buff);
		}
		/*{
		imwrite("../environment_img/q.png", img);
		printf("success!");
    }*/
	}
	}

	void *thread_1(void *)
	{
	}
	void *thread_2(void *)
	{
		int fd;
		fd = Uart_OpenDev(TTY_DEV); //串口初始化
		usart_config(fd);			//配置完成
		while (1)
		{
			my_Uart_RecvFrame(fd);
			if (get_data(buff, 30))
			{
				//printf("%s\n", buff);
				Deal_data->get_vaild_data(buff);
				Deal_data->get_name_data();
				Deal_data->get_instructi_data();
				printf("valid_data:%s\n", Deal_data->valid_data);
				printf("name_data:%s\n", Deal_data->name_data);
				printf("instructi:%s\n", Deal_data->instructi);
			}
		}
	}

	void create_thread(void)
	{
		pthread_t id1, id2; //线程id 全局
		int res;
		res = pthread_create(&id1, NULL, thread_1, NULL);
		if (res) //线程创建失败
		{
			printf("create pthread error!\n");
			return;
		}
		res = pthread_create(&id1, NULL, thread_2, NULL); //创建一个线程
		if (res)										  //线程创建失败
		{
			printf("create pthread error!\n");
			return;
		}
	}

void  Deal_Data::get_vaild_data(const unsigned char *str)
	{
		
		for (int i = 0; i < 18; i++)
		{
			
			valid_data[i] = str[i + 1];
		}
		return ;
	}

void Deal_Data::get_name_data()
	{
		int i = 0;
		while (valid_data[i]!='\0')
         {
			name_data[i] = valid_data[i+4];
			i++;
		 }
	}
void Deal_Data::get_instructi_data()
{
	for (int i = 0; i < 2;i++)
	{
		instructi[i] = valid_data[i + 2];
	}
}

	Deal_Data::Deal_Data()
	{
		memset(valid_data, '\0', sizeof(valid_data));
		memset(name_data, '\0', sizeof(name_data));
		memset(instructi, '\0', sizeof(instructi));
}

 Deal_Data::~Deal_Data()
 {
	 delete (this);
 }
